import React, { useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const Showall = (props) => {
    const { noteslist, setNoteslist } = props;

    useEffect(() => {
        axios.get('http://localhost:8000/api/notes')
            .then(res => setNoteslist(res.data))
            .catch(err => console.log(err));
    }, [setNoteslist])

    return (
        <div className="container">
            <div className="row justify-content-between my-3">
                <div className="col">
                    <h1>Note Wall</h1>
                    <p>Leave a note</p>
                </div>
                <div className="col text-right">
                    <Link className="btn btn-primary" to="/note/new">Write note</Link>
                </div>
            </div>
            <div>
                {noteslist.map(note => (
                    <div key={note._id} className="card mb-3">
                        <div className="card-body">
                            <h5 className="card-title">{note.title}</h5>
                            <p className="card-text">{note.description}</p>
                            <div className="text-right">
                                <Link className="btn btn-secondary" to={`/note/${note._id}`}>Edit</Link>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    )
}

export default Showall;
