import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, useNavigate, Link } from 'react-router-dom';

const Showone = () => {
    const { id } = useParams();
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [errors, setErrors] = useState({});
    const navigate = useNavigate();

    useEffect(() => {
        axios.get(`http://localhost:8000/api/note/${id}`)
            .then(res => {
                setTitle(res.data.title);
                setDescription(res.data.description);
            })
            .catch(err => console.log(err))
    }, [id])

    const onSubmitHandler = e => {
        e.preventDefault();
        axios.put(`http://localhost:8000/api/note/${id}`, {
            title,
            description
        })
            .then(res => navigate('/'))
            .catch(err => {
                if (err.response) {
                    setErrors(err.response.data.errors);
                }
                console.log(err);
            });
    }

    return (
        <div>
            <h1>Note</h1>
            <Link to="/">Go back home</Link>
            <div>
                <form onSubmit={onSubmitHandler}>
                    <p>
                        <label>Title</label><br />
                        <input type="text" onChange={(e) => setTitle(e.target.value)} value={title} />
                        {errors.title && <p style={{ color: 'red' }}>{errors.title.message}</p>}
                    </p>
                    <p>
                        <label>Description</label><br />
                        <input type="text" onChange={(e) => setDescription(e.target.value)} value={description} />
                        {errors.description && <p style={{ color: 'red' }}>{errors.description.message}</p>}
                    </p>
                    <input type="submit" value="Edit note" />
                </form>
            </div>
            <div>
                <button onClick={() => {
                    axios.delete(`http://localhost:8000/api/note/${id}`)
                        .then(res => {
                            console.log(res);
                            navigate('/');
                        })
                        .catch(err => console.log(err));
                }}>Delete</button>
            </div>
        </div>
    )
}

export default Showone;
