import React, { useState } from 'react';
import Showall from '../components/Showall';

const Main = () => {
    const [noteslist, setNoteslist] = useState([]);
    return (
        <div className="App">
            <Showall noteslist={noteslist} setNoteslist={setNoteslist} />
        </div>
    );
}

export default Main;