import './App.css';
import Showone from './components/Showone';
import Main from './view/Main';
import Create from './components/Create';
import {BrowserRouter, Routes, Route} from 'react-router-dom';

function App() {
  return (
  <BrowserRouter>
    <div className="App">
      <Routes>
        <Route path = "/" element = {<Main/>}/>
        <Route path = "/note/new" element = {<Create/>}/>
        <Route path = "/note/:id" element = {<Showone/>}/>
      </Routes>
    </div>
  </BrowserRouter>
  );
}

export default App;
