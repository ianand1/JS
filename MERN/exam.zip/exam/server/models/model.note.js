const mongoose = require('mongoose');

const NoteSchema = new mongoose.Schema({
    title: {
        type: String,
        required: [true, "Title is required"],
        minlength: [2, "Title must be at least 2 characters long"],
    },
    description: {
        type: String,
        required: [true, "Description is required"],
        minlength: [2, "Description must be at least 2 characters long"],
        maxlength: [255, "Description must be less than 255 characters long"],
    },
}, {
    timestamps: true,
});

const Note = mongoose.model('Note', NoteSchema);

module.exports = Note;
