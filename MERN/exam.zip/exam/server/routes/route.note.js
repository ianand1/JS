const NoteController = require('../controllers/controller.note');

module.exports = (app) => {
    app.post('/api/notes', NoteController.createNote);
    app.get('/api/notes', NoteController.getallNote);
    app.get('/api/note/:id', NoteController.getoneNote);
    app.put('/api/note/:id', NoteController.updateNote);
    app.delete('/api/note/:id', NoteController.deleteNote);
}