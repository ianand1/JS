import './App.css';
import Userform from './compoent/Userform';

function App() {
  return (
    <div className="App">
      <Userform />
    </div>
  );
}

export default App;
