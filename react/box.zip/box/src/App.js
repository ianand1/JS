import React, { useState } from 'react';
import Form from './component/Form';
import Display from './component/Display';
import './App.css';

function App() {
  const [ArryColor, setArryColor] = useState([])
  return (
    <div className="App">
      <Form ArryColor={ArryColor} setArryColor={setArryColor} />
      <Display ArryColor={ArryColor} />
    </div>
  );
}

export default App;
