import React, { useState } from 'react';

const Form = (props) => {
    const { ArryColor, setArryColor } = props;
    const [color, setColor] = useState('');

    const addbox = (e) => {
        e.preventDefault();
        setArryColor([...ArryColor, color]);
    };

    return (
        <div>
            <form onSubmit={addbox}>
                <div>
                    <label htmlFor="color">Color:</label>
                    <input
                        type="text"
                        name="color"
                        onChange={(e) => setColor(e.target.value)}
                        value={color}
                    />
                </div>
                <input type="submit" value="Add Box" />
            </form>
        </div>
    );
};

export default Form;
