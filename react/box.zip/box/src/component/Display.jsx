import React from 'react'

const Display = (props) => {
    const { ArryColor } = props;

    return (
        <div>
            {
                ArryColor.map((color, i) =>
                    <div key={i} style={{ 
                        backgroundColor: color, 
                        width: '100px', 
                        height: '100px',
                        display:'inline-block',
                        margin: '10px',
                        }}>
                        </div>
                )
            }
        </div>
    );
};

export default Display
