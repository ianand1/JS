import React from 'react'

const Person = (props) => {
    const {name, age, hairColor} = props;

    return (
        <div className='container'>
            <h1>{props.name}</h1>
            <h3>Age:{props.age}</h3>
            <h3>Hair Color:{props.hairColor}</h3>
        </div>
    );
}

export default Person